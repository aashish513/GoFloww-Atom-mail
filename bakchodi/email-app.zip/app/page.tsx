"use client"

import Mail from "../src/components/Mail"

export default function SyntheticV0PageForDeployment() {
  return <Mail />
}